package com.example.java_auth_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ShowPostActivity extends AppCompatActivity {

    TextView title, content, uid;
    ImageView image;
    Button modify, delete;
    AlertDialog.Builder alt_modify, alt_delete;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("POST");

    FirebaseStorage storage=FirebaseStorage.getInstance();
    StorageReference stoRef=storage.getReference("POST_IMG");

    private FirebaseAuth mAuth;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showpost);

        Intent intent=getIntent();

        mAuth=FirebaseAuth.getInstance();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        String UID=currentUser.getUid();

        String intent_uid=intent.getExtras().getString("writer");
        String intent_time=intent.getExtras().getString("time");
        String intent_title=intent.getExtras().getString("title");
        String intent_content=intent.getExtras().getString("content");
        String intent_picture=intent.getExtras().getString("picture");

        title=findViewById(R.id.showtitle);
        content=findViewById(R.id.showcontent);
        uid=findViewById(R.id.uid);
        modify=findViewById(R.id.modify);
        delete=findViewById(R.id.delete);
        image=findViewById(R.id.imageView);

        //수정 넘어갈 때 필요함
        int num=1;

        alt_modify =new AlertDialog.Builder(this);
        alt_delete = new AlertDialog.Builder(this);

        title.setText(intent_title);
        content.setText(intent_content);
        uid.setText(intent_time);

        System.out.println(intent_picture);

        if(intent_picture.equals("true")){
            image.setVisibility(View.VISIBLE);
            stoRef.child(intent_time).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>(){
                @Override
                public void onSuccess(Uri uri) {
                    System.out.println("성공!");
                    Glide.with(ShowPostActivity.this).load(uri).into(image);
                }
            });

        }

        if(intent_uid.equals(UID)){
            System.out.println("intent_uid와 UID는 같습니다.");
            modify.setVisibility(View.VISIBLE);
            delete.setVisibility(View.VISIBLE);

            //수정
            modify.setOnClickListener(new Button.OnClickListener(){

                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(ShowPostActivity.this, AddPostActivity.class);
                    intent.putExtra("title", intent_title);
                    intent.putExtra("content", intent_content);
                    intent.putExtra("writer", intent_uid);
                    intent.putExtra("time", intent_time);
                    intent.putExtra("picture", intent_picture);
                    intent.putExtra("show_num", num);

                    System.out.println("intent_picture : "+intent_picture);

                    startActivity(intent);
                }
            });

            //삭제
            delete.setOnClickListener(new Button.OnClickListener(){
                @Override
                public void onClick(View v) {
                    alt_delete.setTitle("확인").setMessage("게시물을 삭제하시겠습니까?").setPositiveButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            myRef.child(intent_time).removeValue().addOnSuccessListener(new OnSuccessListener<Void>(){

                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(ShowPostActivity.this, "삭제 성공", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(ShowPostActivity.this, "삭제 실패", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            });
                            stoRef.child(intent_time).delete();

                        }
                    }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).create().show();
                }
            });

        }
        else{
            System.out.println("intent_uid : "+intent_uid+"\nUID : "+UID);
        }

    }
}
