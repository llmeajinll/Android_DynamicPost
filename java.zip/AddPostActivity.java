



package com.example.java_auth_test;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AddPostActivity extends AppCompatActivity {

    ListView listView;
    ListItemAdapter adapter;

    Button finish, x;
    EditText title, content;
    ImageView image;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("POST");

    FirebaseStorage storage=FirebaseStorage.getInstance();
    StorageReference stoRef=storage.getReference("POST_IMG");

    private FirebaseAuth mAuth;
    Date mDate;

    SimpleDateFormat mFormate=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:ms");

    int num=0;
    Uri uri;
    String uri_str;
    Boolean picture=false;
    HashMap result = new HashMap<>();
    ListItem listitem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpost);

        adapter=new ListItemAdapter();
        mDate=new Date();

        finish=findViewById(R.id.finish);
        listView= findViewById(R.id.listview);

        title=findViewById(R.id.edittitle);
        content=findViewById(R.id.editcontent);
        image=findViewById(R.id.addimage);
        x=findViewById(R.id.x);

        mAuth=FirebaseAuth.getInstance();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        String UID=currentUser.getUid();
        String time = mFormate.format(mDate);

        Intent show_intent=getIntent();

        String int_title=show_intent.getExtras().getString("title");
        String int_content=show_intent.getExtras().getString("content");
        String int_writer=show_intent.getExtras().getString("writer");
        String int_time=show_intent.getExtras().getString("time");
        String int_picture=show_intent.getExtras().getString("picture");

        if(int_picture.equals("true")) x.setVisibility(View.VISIBLE);

        if(int_title.equals("")&&int_content.equals("")&&int_writer.equals("")&&int_time.equals("")){

        }
        //수정 버튼 눌러서 넘어왔을 때
        else{
            num+=1;
            title.setText(int_title);
            content.setText(int_content);
            stoRef.child(int_time).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>(){

                @Override
                public void onSuccess(Uri uri) {
                    System.out.println("성공!");
                    Glide.with(AddPostActivity.this).load(uri).into(image);
                }
            });
        }

        //완료 버튼
        finish.setOnClickListener(v -> {

            String title_txt=title.getText().toString();
            String content_txt=content.getText().toString();

            //처음 글쓸때
            if(num==0) {

                if(uri!=null){
                    stoRef.child(time).putFile(uri);
                }
//                result.put("title", title_txt);
//                result.put("writer", UID);
//                result.put("content", content_txt);
//                result.put("picture", picture);
//                result.put("time", time);
//                result.put("uri", uri_str);
                writeItem(title_txt, content_txt, UID, time, picture);

                finish();
            }
            //글쓴거 수정할 때
            else{
                Map<String, Object> update = new HashMap<>();

                update.put("title", title_txt);
                update.put("content", content_txt);
                update.put("picture", picture);

                if(uri!=null){
                    stoRef.child(int_time).putFile(uri);
                }
                else{
                    stoRef.child(int_time).delete();
                }

                myRef.child(int_time).updateChildren(update);

                Intent intent=new Intent(AddPostActivity.this, MainMenuActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

                finish();
            }

        });

        image.setOnClickListener(b -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 0);


        });

        x.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                image.setImageResource(0);//image에 사진 넣을꺼면 그 사진 경로 넣으면 됨
                uri=null;
                picture=false;
                x.setVisibility(View.GONE);

            }
        });

    }

    void writeItem(String title, String writer, String content, String time, Boolean picture){
        ListItem listitem=new ListItem(title, writer, content, time, picture);


        System.out.println("ListItem : "+listitem);

        //data save
        myRef.child(time).setValue(listitem);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && data!=null&&data!=null){

            Uri selectedImageUri = data.getData();
            image.setImageURI(selectedImageUri);
            x.setVisibility(View.VISIBLE);
            uri=selectedImageUri;
            picture=true;

            System.out.println("절대 경로 : "+getPath(selectedImageUri));



        }
        else{
            Toast.makeText(AddPostActivity.this, "result fail", Toast.LENGTH_SHORT).show();
        }
    }
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

}
