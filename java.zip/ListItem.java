package com.example.java_auth_test;


import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;

import java.net.URI;

public class ListItem {
    private String title;
    private String content;
//    private String image;
    private String writer;
    private String time;
    private Boolean picture;

    ListItem(){}
    ListItem(String title, String content, String writer, String time, Boolean picture){
        this.title=title;
        this.content=content;
        this.writer=writer;
        this.time=time;
        this.picture=picture;
//        this.image=image;
    }

    public void setTitle(String title){ this.title=title; }
    public void setContent(String content){ this.content=content; }
    public void setWriter(String writer){this.writer=writer;}
    public void setTime(String time){this.time=time;}
    public void setPicture(Boolean picture){this.picture=picture;}
//    public void setImage(String image){this.image=image;}

    public String getTitle(){ return title; }
    public String getContent(){ return content; }
    public String getWriter() { return writer; }
    public String getTime(){return time;}
    public Boolean getPicture(){return picture;}
//    public String getImage(){return image;}
}
