package com.example.java_auth_test;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class MainMenuActivity extends AppCompatActivity {

    ListView listView;
    ListItemAdapter adapter;
    Button write, find;
    TextView showuid, getdata;

    ArrayList<ListItem> data;
    ArrayList<String> key;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("POST");
    private FirebaseAuth mAuth;

    int num=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);

        mAuth=FirebaseAuth.getInstance();

        write=findViewById(R.id.write);
        showuid=findViewById(R.id.showuid);
        listView=findViewById(R.id.listview);
        getdata=findViewById(R.id.getdata);
        find=findViewById(R.id.find_btn);

        adapter=new ListItemAdapter();
        data=new ArrayList<>();
        key=new ArrayList<>();

        FirebaseUser currentUser=mAuth.getCurrentUser();
        String UID=currentUser.getUid();

        myRef.addValueEventListener(new ValueEventListener(){

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                adapter.clear();
                data.clear();
                key.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    ListItem listitem = snapshot.getValue(ListItem.class);
                    System.out.println("getKey() test : "+snapshot.getKey());
                    key.add(0, snapshot.getKey());
                    data.add(0, listitem);
                    adapter.addItem(listitem.getTitle(), listitem.getContent(), listitem.getWriter(), snapshot.getKey(), 0, listitem.getPicture());
                    System.out.println(listitem.getTitle()+" : "+listitem.getContent());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("The read failed : "+error.getCode());
            }
        });

        showuid.setText(UID);

        //글작성
        write.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainMenuActivity.this, AddPostActivity.class);
                intent.putExtra("title", "");
                intent.putExtra("content", "");
                intent.putExtra("time", "");
                intent.putExtra("writer", "");
                intent.putExtra("picture", "");

                startActivity(intent);
            }
        });

        find.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainMenuActivity.this, FindActivity.class);
                startActivity(intent);
            }
        });

        listView.setAdapter(adapter);

        //리스트뷰 눌렀을 때
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent =new Intent(MainMenuActivity.this, ShowPostActivity.class);

                intent.putExtra("title", data.get(position).getTitle());
                intent.putExtra("content", data.get(position).getContent());
                intent.putExtra("writer", data.get(position).getWriter());
                intent.putExtra("time", data.get(position).getTime());
                intent.putExtra("picture", data.get(position).getPicture().toString());

                startActivity(intent);
            }
        });
    }
}
