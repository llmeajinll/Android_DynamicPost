package com.example.java_auth_test;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.Collections;

public class ListItemAdapter extends BaseAdapter {
    ArrayList<ListItem> items = new ArrayList<>();

    Context context;

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        context = parent.getContext();
        ListItem listItem = items.get(position);

        FirebaseStorage storage=FirebaseStorage.getInstance();
        StorageReference stoRef=storage.getReference("POST_IMG");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("POST");

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.costom_listview, parent, false);
        }

        TextView title=convertView.findViewById(R.id.title);
        TextView content=convertView.findViewById(R.id.content);
        TextView uid= convertView.findViewById(R.id.id);
        TextView time=convertView.findViewById(R.id.time);

        ImageView image=convertView.findViewById(R.id.image);

        title.setText(listItem.getTitle());
        content.setText(listItem.getContent());
        uid.setText(listItem.getWriter());
        time.setText(listItem.getTime());

//        System.out.println("getpicture() : "+myRef.child(listItem.getTime()));

        if(listItem.getPicture()==true){
            image.setVisibility(View.VISIBLE);
            View finalConvertView = convertView;
            stoRef.child(listItem.getTime()).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>(){

                @Override
                public void onSuccess(Uri uri) {
                    System.out.println("성공!");
                    Glide.with(finalConvertView).load(uri).into(image);
                }
            });


        }
        else{
            image.setVisibility(View.GONE);
        }
        this.notifyDataSetChanged();
        return convertView;
    }
    public void addItem(String title, String content, String writer, String time, int zero, boolean picture){
        ListItem listitem=new ListItem();

        listitem.setTitle(title);
        listitem.setContent(content);
        listitem.setTime(time);
        listitem.setWriter(writer);
        listitem.setPicture(picture);

        items.add(zero, listitem);
        this.notifyDataSetChanged();
    }
    public void clear(){
        items.clear();
    }


}
