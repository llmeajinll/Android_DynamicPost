package com.example.java_auth_test;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FindActivity extends AppCompatActivity {

    ListView findlist;
    ListItemAdapter adapter;
    EditText findpost;

    ArrayList<ListItem> data;
    ArrayList<String> key;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("POST");

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findpost);

        findlist=findViewById(R.id.edit);
        findpost=findViewById(R.id.find_edit);

        adapter=new ListItemAdapter();
        data=new ArrayList<>();
        key=new ArrayList<>();

        findpost.addTextChangedListener(new TextWatcher(){

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                adapter.clear();
                data.clear();
                key.clear();
                myRef.addValueEventListener(new ValueEventListener(){

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        adapter.clear();
                        data.clear();
                        key.clear();
                        String post=findpost.getText().toString();
                        for (DataSnapshot Snapshot : snapshot.getChildren()){
                            ListItem listitem = Snapshot.getValue(ListItem.class);
                            System.out.println("post : "+post);
                            if(listitem.getTitle().contains(post)||listitem.getContent().contains(post)){
                                System.out.println("포함함");
                                key.add(0, Snapshot.getKey());
                                data.add(0, listitem);
                                adapter.addItem(listitem.getTitle(), listitem.getContent(), listitem.getWriter(), Snapshot.getKey(), 0, listitem.getPicture());
                                System.out.println("findactivity : "+listitem.getTitle()+" : "+listitem.getContent());
                            }
                            else{
                                System.out.println("패스");
                            }

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        System.out.println("The read failed : "+error.getCode());
                    }
                });

            }
        });

        findlist.setAdapter(adapter);

        //리스트뷰 눌렀을 때
        findlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent =new Intent(FindActivity.this, ShowPostActivity.class);

                intent.putExtra("title", data.get(position).getTitle());
                intent.putExtra("content", data.get(position).getContent());
                intent.putExtra("writer", data.get(position).getWriter());
                intent.putExtra("time", data.get(position).getTime());
                intent.putExtra("picture", data.get(position).getPicture().toString());

                startActivity(intent);
            }
        });

    }


}
